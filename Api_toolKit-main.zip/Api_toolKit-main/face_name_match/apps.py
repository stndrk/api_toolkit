from django.apps import AppConfig


class FaceNameMatchConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'face_name_match'