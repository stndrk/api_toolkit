// Set date picker on UI
$(function(){
    $("#transaction_date").datepicker({ dateFormat: 'dd-mm-yy' });
    $("#payout_date").datepicker({ dateFormat: 'dd-mm-yy' });
});